# CARLON HRV Research – sample data

One real recording, exported with CARLON HRV Research 1.4 (build 2026102801) exactly as a user would receive it.

- **Session:** gym training, 47 min 51 s, 5,544 beats, heart rate up to about 155 bpm
- **Sensor:** Polar H10 chest strap, RR intervals in 1 ms resolution
- **Participant:** pseudonymized (ANON-…), shared with consent for free use. Please do not try to re-identify the person.
- **Recording path and start-time source:** not stored with this recording. The files say so ("unknown") rather than guess.
- **Event markers:** none in this session; the segment table uses fixed time windows.
- **Same recording everywhere:** the example report and the example figures on the product page are this session's report and figures, from the same build (identical RR SHA-256).

## Files

| File | What it is |
|---|---|
| `…_complete.csv` | Original RR intervals plus each beat's artifact flag and correction. The header carries the exact settings for the Kubios HRV custom text import. |
| `…_kubios.txt` | One RR interval in ms per line, for direct import into Kubios HRV |
| `…_complete.json` | Complete export: all metrics with their method, per-beat classification, append-only audit trail (SHA-256 hash chain) and W3C PROV |
| `…_dfa_alpha1.csv` | DFA α1 over time: 2-minute windows every 5 s, with heart rate, RMSSD and the share of corrected beats per window |
| `….edf` | EDF+ (European Data Format) with the RR series |
| `….hea` / `….atr` | WFDB (PhysioNet) header and beat annotations |
| `….fit` | FIT file with the RR intervals |
| `…_report-print.pdf` | PDF report with every metric, figures, limitations and a methods paragraph to cite |
| `…_figures.zip` | Every figure as vector PDF and 300-dpi PNG in journal column widths (85 and 175 mm) |

The original RR values are never changed. Artifact flags and corrections are listed beside them.

## Load it

- **Kubios HRV:** open `…_kubios.txt`, or use the custom text import with the settings from the CSV header.
- **Python:** `pandas.read_csv(path, comment="#")`, then the `RR_Interval_ms` column (original) or `RR_corrected_ms`. NeuroKit2 or SciPy can recompute every value.
- **R:** `read.csv(path, comment.char = "#")`.

## Licence and citation

Data: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Please cite:

Rohwedder, J. (2026). CARLON HRV Research (Version 1.4, build 2026102801) [Mobile application software]. vitalkultur. https://vitalkultur.com/hrv-research/

Validation dossier: https://vitalkultur.com/hrv-research/CARLON-HRV-Research-Validation-Dossier.pdf
